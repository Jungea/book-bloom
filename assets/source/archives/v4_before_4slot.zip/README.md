# Library Tycoon assets V4

Based on the first generated reference image: a large beige wall, dark slate status bar, perspective gray tiled floor, a more detailed walnut desk and return station, cream CRT monitor, black metal shelf with muted books, and a larger apron-wearing librarian. The V4 composition is intentionally different from the four equal V3 slots. `preview.png` is a composited 1280×720 game preview; `reference_original.png` is the exact image used as visual direction, retained for comparison.

Objects are separate RGBA PNGs at 2× logical size. The bookshelf is empty, with book spines in `books/`; monitor and returned books are separate. The additional facilities are style extensions, since they are absent from the generated reference. Blank display areas accept runtime text or covers.

Render backgrounds, furniture, detachable books/monitor, characters, then UI and effects. Use nearest-neighbor scaling. The preview is an authored approximation rather than a pixel-for-pixel segmentation of the original generated picture.

Created for this project; no third-party asset pack is included.
